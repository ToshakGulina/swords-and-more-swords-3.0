---
author: mammerla
ms.author: mikeam
title: "Biome Documentation - minecraft:overworld_height"
description: "Describes the minecraft:overworld_height biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Biome Documentation - minecraft:overworld_height

Noise parameters used to drive terrain height in the Overworld.

> [!Note]
> This is a pre-Caves and Cliffs component. It does not change overworld height, and currently only affects map item rendering.


## Biome Overworld Height Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| noise_params | *not set* | Array of numbers | First value is depth - more negative means deeper underwater, while more positive means higher. | 
| noise_type | *not set* | [Noise Type](#noise-type-choices) choices | Specifies a preset based on a built-in setting rather than manually using noise_params | 

### noise_params

First value is depth - more negative means deeper underwater, while more positive means higher. Second value is scale, which affects how much noise changes as it moves from the surface. Value must have at least 2 items. Value must have at most 2 items.


### Noise Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| beach | Beach | |
| deep_ocean | Deep ocean | |
| default | Default | |
| default_mutated | Default mutated | |
| extreme | Extreme | |
| highlands | Highlands | |
| less_extreme | Less extreme | |
| lowlands | Lowlands | |
| mountains | Mountains | |
| mushroom | Mushroom | |
| ocean | Ocean | |
| river | River | |
| stone_beach | Stone beach | |
| swamp | Swamp | |
| taiga | Taiga | |