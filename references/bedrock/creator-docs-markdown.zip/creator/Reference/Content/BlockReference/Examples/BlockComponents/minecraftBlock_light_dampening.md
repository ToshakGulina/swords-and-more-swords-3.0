---
author: mammerla
ms.author: mikeam
title: "Block Components Documentation - minecraft:light_dampening"
description: "Describes the minecraft:light_dampening block component"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Block Components Documentation - minecraft:light_dampening

The amount that light will be dampened when it passes through the block, in a range of 0-15. Higher value means the light will be dampened more. A value of 15 means fully opaque (like stone), while 0 means fully transparent (like glass). Leaves use 1, water uses 2.

> [!Note]
> In format version 1.26.20, validation strictly enforces that the value must be an integer between 0 and 15 inclusive; out-of-range values are rejected at load time.

## Alternate Simple Representations

This item can also be represented as a `Integer number`.


## Samples

#### [Block Chiseled Packed Ice](https://github.com/Mojang/bedrock-samples/tree/preview/behavior_pack/blocks/chiseled_packed_ice.block.json)


```json
"minecraft:light_dampening": 15
```
