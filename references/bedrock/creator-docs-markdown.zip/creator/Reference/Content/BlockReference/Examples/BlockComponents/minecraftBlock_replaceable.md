---
author: mammerla
ms.author: mikeam
title: "Block Components Documentation - minecraft:replaceable"
description: "Describes the minecraft:replaceable block component"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Block Components Documentation - minecraft:replaceable

A block with this component can be replaced when another block is placed in the same block position.
Experimental toggles required: Upcoming Creator Features (in format versions before 1.21.60).

> [!Note]
> This item requires a format version of at least 1.21.70.


## Samples

#### [Block Red Shrub](https://github.com/Mojang/bedrock-samples/tree/preview/behavior_pack/blocks/red_shrub.block.json)


```json
"minecraft:replaceable": {}
```
