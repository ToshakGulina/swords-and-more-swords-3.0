---
author: mammerla
ms.author: mikeam
title: "Block Components Documentation - minecraft:entity_fall_on"
description: "Describes the minecraft:entity_fall_on block component"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Block Components Documentation - minecraft:entity_fall_on

Configures what distance an entity must fall onto this block to cause the `onEntityFallOn` block custom component event to be sent to script. Custom components subscribed to the `onEntityFallOn` event on a block without the `minecraft:entity_fall_on` component use the default fall distance of 1 block.


## Entity Fall On Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| min_fall_distance | 0 | Decimal number | The minimum distance in blocks that an actor needs to fall before events are triggered. | 
| minimum_fall_distance | 1 | Decimal number | The minimum distance in blocks that an entity needs to fall before events are raised. | 

## Samples

#### Fall Distance Of 2 Blocks


```json
"minecraft:entity_fall_on": {
  "minimum_fall_distance": 2
}
```
