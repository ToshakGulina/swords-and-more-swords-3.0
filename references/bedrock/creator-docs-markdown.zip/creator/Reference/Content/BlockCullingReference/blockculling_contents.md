---
author: mammerla
ms.author: mikeam
title: "Block Culling Documentation - minecraft:blockculling_contents"
description: "Describes the minecraft:blockculling_contents block culling"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Block Culling Documentation - minecraft:blockculling_contents

BlockCulling Contents.


## BlockCulling Contents Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| bone | *not set* | String | bone | 
| cube | *not set* | Integer number | cube | 
| face | *not set* | String | Facing | 