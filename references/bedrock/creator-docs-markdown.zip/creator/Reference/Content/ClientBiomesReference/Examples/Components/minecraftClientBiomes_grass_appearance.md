---
author: mammerla
ms.author: mikeam
title: "Client Biome Documentation - minecraft:grass_appearance"
description: "Describes the minecraft:grass_appearance client biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Client Biome Documentation - minecraft:grass_appearance

Set the grass color or color map used during rendering. Biomes without this component will have default grass appearance.


## Client Biome Grass Appearance Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| color | *not set* | Object | RGB color of grass. | 