---
author: mammerla
ms.author: mikeam
title: "Camera Documentation - minecraft:cameraaimassistcategoriesdefinition"
description: "Describes the minecraft:cameraaimassistcategoriesdefinition camera definition"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Camera Documentation - minecraft:cameraaimassistcategoriesdefinition

CameraAimAssistCategoriesDefinition.

> [!Note]
> This item requires a format version of at least 1.21.70.


## CameraAimAssistCategoriesDefinition Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| categories | *not set* | Array of objects | List of categories used by Camera Aim-Assist 'minecraft:aim_assist_preset'. | 