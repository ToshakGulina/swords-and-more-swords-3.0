---
author: mammerla
ms.author: mikeam
title: "Client Biome Documentation - minecraft:color_grading_identifier"
description: "Describes the minecraft:color_grading_identifier client biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Client Biome Documentation - minecraft:color_grading_identifier

Set the identifier used for color grading in Vibrant Visuals mode. Identifiers must resolve to identifiers in valid Color Grading JSON schemas under the "color_grading" directory. Biomes without this component will have default color_grading settings.


## Client Biome Color Grading Identifier Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| color_grading_identifier | *not set* | String | Identifier of color_grading definition to use | 