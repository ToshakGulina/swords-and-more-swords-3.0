---
author: mammerla
ms.author: mikeam
title: "Biome Documentation - minecraft:custom_map_tint_grass_noise"
description: "Describes the minecraft:custom_map_tint_grass_noise biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Biome Documentation - minecraft:custom_map_tint_grass_noise

Makes grass use the noise based colors for tinting in this biome on the map.


## Biome Custom Map Tint Grass Noise Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| type | noise | [Type](#type-choices) choices | Controls the type of grass tint to use. | 

### Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| noise | Noise | |
| tint | Tint | |