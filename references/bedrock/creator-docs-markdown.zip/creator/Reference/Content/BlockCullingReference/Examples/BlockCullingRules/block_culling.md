---
author: mammerla
ms.author: mikeam
title: "Block Culling Documentation - minecraft:block_culling"
description: "Describes the minecraft:block_culling block culling"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Block Culling Documentation - minecraft:block_culling

Block culling rules allow custom blocks with geometry to have specific faces hidden when adjacent to other blocks. This improves rendering performance by not drawing faces that aren't visible. Culling conditions include 'same_block' (hide when adjacent to same block type) and 'same_culling_layer' (hide when adjacent to blocks in the same layer, useful for glass-like blocks).


## Block Culling Rules Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| description | *not set* | [Description](#client-block-description) item |  | 
| rules | *not set* | Array of [Rules](#client-block-rule) items |  | 

### Client Block Description
Defines the identifier for a block culling rule.


#### Client Block Description Properties

**JSON path:** `description`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| identifier | *not set* | String | The namespace and identifier for this culling rule. | 

### Client Block Rule
Specifies a culling rule for block face visibility.


#### Client Block Rule Properties

**JSON path:** `rules`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| condition | *not set* | [Condition](#condition-choices) choices |  | 
| cull_against_full_and_opaque | true | Boolean true/false | If set to false, then culling against full and opaque blocks will not be considered. | 
| direction | *not set* | [Direction](#direction-choices) choices |  | 
| geometry_part | *not set* | [Geometry Part](#client-block-rule-geometry-part) item |  | 

### Condition choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| default | Default | The condition will succeed if the neighbor is a full and opaque block.|
| same_block | Same block | The condition wil succeed if the neighbor block as the same identifier.|
| same_block_permutation | Same block permutation | The condition will succeed if the neighbor block has the same identifier and is the exact same permutation.|
| same_culling_layer | Same culling layer | The condition will succeed if if the neighbor block shares the same culling_layer as the block being occluded, defined in the geometry component.|

### Direction choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| down | Down | |
| east | East | |
| north | North | |
| south | South | |
| up | Up | |
| west | West | |

#### Client Block Rule Geometry Part
Specifies a geometry part for culling.


##### Client Block Rule Geometry Part Properties

**JSON path:** `rules > geometry_part`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| bone | *not set* | String |  | 
| cube | *not set* | Integer number |  | 
| face | *not set* | [Face](#direction-choices) choices |  | 

## Samples

#### Culling Rules Horizontal Glass


```json
{
  "format_version": "1.21.80",
  "minecraft:block_culling_rules": {
    "description": {
      "identifier": "demo:horizontal_glass"
    },
    "rules": [
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "north"
        },
        "direction": "north",
        "condition": "same_block"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "south"
        },
        "direction": "south",
        "condition": "same_block"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "east"
        },
        "direction": "east",
        "condition": "same_block"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "west"
        },
        "direction": "west",
        "condition": "same_block"
      }
    ]
  }
}
```

#### Culling Rules Leaves


```json
{
  "format_version": "1.21.80",
  "minecraft:block_culling_rules": {
    "description": {
      "identifier": "demo:leaves"
    },
    "rules": [
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "north"
        },
        "direction": "north",
        "condition": "same_culling_layer"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "west"
        },
        "direction": "west",
        "condition": "same_culling_layer"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "up"
        },
        "direction": "up",
        "condition": "same_culling_layer"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "south"
        },
        "direction": "south"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "east"
        },
        "direction": "east"
      },
      {
        "geometry_part": {
          "bone": "block",
          "cube": 0,
          "face": "down"
        },
        "direction": "down"
      }
    ]
  }
}
```
