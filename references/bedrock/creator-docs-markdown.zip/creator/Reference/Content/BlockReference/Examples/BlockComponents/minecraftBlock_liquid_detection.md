---
author: mammerla
ms.author: mikeam
title: "Block Components Documentation - minecraft:liquid_detection"
description: "Describes the minecraft:liquid_detection block component"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Block Components Documentation - minecraft:liquid_detection

The definitions for how a block behaves when detecting liquid. Only one rule definition is allowed per liquid type - if multiple are specified, the first will be used and the rest will be ignored.

> [!Note]
> In 1.26.10, defining `minecraft:liquid_detection` with an empty `detection_rules` array fails to load and produces a content error.

> [!Note]
> This item requires a format version of at least 1.21.60.


## Block Liquid Detection Properties

|Name       |Default Value |Type |Description |Example Values |
|:----------|:-------------|:----|:-----------|:------------- |
| can_contain_liquid | false | Boolean true/false | Whether this block can contain the liquid. For example, if the liquid type is `water`, this means the block can be waterlogged. |  | 
| detection_rules | *not set* | Array of [Detection Rules](#block-detection-rule) items |  | Block Black Concrete Slab: `[{"liquid_type":"water","can_contain_liquid":true,"on_liquid_touches":"blocking"}]` | 
| liquid_type | water | String | The type of liquid this detection rule is for. Currently, `water` is the only supported liquid type. If this field is omitted, `water` will be the liquid type by default. |  | 
| on_liquid_touches | blocking | Minecraft Event Trigger | How the block reacts to flowing water. |  | 
| stops_liquid_flowing_from_direction | *not set* | Array of strings | When a block contains a liquid, controls the directions in which the liquid can't flow out from the block. |  | 
| use_liquid_clipping | false | Boolean true/false | Whether this block uses the encompassing collider to visually clip the liquid. |  | 

### on_liquid_touches

How the block reacts to flowing water. Must be one of the following options: "blocking" - The default value for this field. The block stops the liquid from flowing. "broken" - The block is destroyed completely. "popped" - The block is destroyed and its item is spawned. "no_reaction" - The block is unaffected; visually, the liquid will flow through the block.

### stops_liquid_flowing_from_direction

When a block contains a liquid, controls the directions in which the liquid can't flow out from the block. Also controls the directions in which a block can stop liquid flowing into it if `no_reaction` is set for the `on_liquid_touches` field. Can be a list of the following directions: "up", "down", "north", "south", "east", "west". The default is an empty list; this means that liquid can flow out of all directions by default.

### use_liquid_clipping

Whether this block uses the encompassing collider to visually clip the liquid. The encompassing collider is the smallest single AABB that contains all of the block's colliders. A liquid's base visual shape is ALWAYS a quad, they do not have more subdivisions. When use_liquid_clipping is TRUE, the game will attempt to reduce the visible volume of water if the collision shape allows it. Eg. a wall will turn the water base shape into a rectangle on the side of the incoming water. When use_liquid_clipping is FALSE, the game will preserve the water base shape as a full square, no matter what the collision shape of the block they share space with is.


### Block Detection Rule

#### Block Detection Rule Properties

**JSON path:** `detection_rules`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| can_contain_liquid | false | Boolean true/false | Whether this block can contain the liquid. For example, if the liquid type is `water`, this means the block can be waterlogged. | 
| liquid_type | water | [Liquid Type](#liquid-type-choices) choices | The type of liquid this detection rule is for. Currently, `water` is the only supported liquid type. If this field is omitted, `water` will be the liquid type by default. | 
| on_liquid_touches | blocking | [Liquid Touches](#liquid-touches-choices) choices | How the block reacts to flowing water. | 
| stops_liquid_flowing_from_direction | [] | Object | When a block contains a liquid, controls the directions in which the liquid can't flow out from the block. | 
| use_liquid_clipping | false | Boolean true/false | If true, the block uses its collision box to visually clip the liquid (reducing the visible water volume to match the block's shape). | 

#### on_liquid_touches

How the block reacts to flowing water. Must be one of the following options: "blocking" - The default value for this field. The block stops the liquid from flowing. "broken" - The block is destroyed completely. "popped" - The block is destroyed and its item is spawned. "no_reaction" - The block is unaffected; visually, the liquid will flow through the block.

#### stops_liquid_flowing_from_direction

When a block contains a liquid, controls the directions in which the liquid can't flow out from the block. Also controls the directions in which a block can stop liquid flowing into it if `no_reaction` is set for the `on_liquid_touches` field. Can be a list of the following directions: "up", "down", "north", "south", "east", "west". The default is an empty list; this means that liquid can flow out of all directions by default.

#### use_liquid_clipping

If true, the block uses its collision box to visually clip the liquid (reducing the visible water volume to match the block's shape). If false, the liquid renders as a full square across the whole block regardless of the collision shape. This item requires a format version of at least 1.26.0. Added to `detection_rules` entries in 1.26.0. Defaults to `true` for format_version older than 1.26.0 and to `false` for 1.26.0 and newer.


### Liquid Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| water | Water | |

### Liquid Touches choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| blocking | Blocking | |
| broken | Broken | |
| no_reaction | No reaction | |
| popped | Popped | |

## Samples

#### Block Fabricator


```json
"minecraft:liquid_detection": {
  "detection_rules": [
    {
      "liquid_type": "water",
      "on_liquid_touches": "broken"
    }
  ]
}
```

#### Block Leaf Pile


```json
"minecraft:liquid_detection": {
  "detection_rules": [
    {
      "liquid_type": "water",
      "on_liquid_touches": "popped"
    }
  ]
}
```

#### [Block Black Concrete Slab](https://github.com/Mojang/bedrock-samples/tree/preview/behavior_pack/blocks/black_concrete_slab.block.json)


```json
"minecraft:liquid_detection": {
  "detection_rules": [
    {
      "liquid_type": "water",
      "can_contain_liquid": true,
      "on_liquid_touches": "blocking"
    }
  ]
}
```
