---
author: mammerla
ms.author: mikeam
title: "Biome Documentation - minecraft:mesa"
description: "Describes the minecraft:mesa biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Biome Documentation - minecraft:mesa

Similar to overworld_surface. Adds colored strata and optional pillars.


## Biome Mesa Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| bryce_pillars | *not set* | Boolean true/false | Whether the mesa generates with pillars | 
| clay_material | *not set* | String | Base clay block to use | 
| clay_material (Clay Material) | *not set* | [Clay Material (Clay Material)](#clay-material-clay-material) item |  | 
| foundation_material | *not set* | String | Controls the block type used deep underground in this biome. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| hard_clay_material | *not set* | String | Hardened clay block to use | 
| hard_clay_material (Hard Clay Material) | *not set* | [Hard Clay Material (Hard Clay Material)](#hard-clay-material-hard-clay-material) item |  | 
| has_forest | *not set* | Boolean true/false | Places coarse dirt and grass at high altitudes | 
| mid_material | *not set* | String | Controls the block type used in a layer below the surface of this biome. | 
| mid_material (Mid Material) | *not set* | [Mid Material (Mid Material)](#mid-material-mid-material) item |  | 
| sea_floor_depth | *not set* | Integer number | Controls how deep below the world water level the floor should occur. Value must be <= 127. | 
| sea_floor_material | *not set* | String | Controls the block type used as a floor for bodies of water in this biome. | 
| sea_floor_material (Sea Floor Material) | *not set* | [Sea Floor Material (Sea Floor Material)](#sea-floor-material-sea-floor-material) item |  | 
| sea_material | *not set* | String | Controls the block type used for the bodies of water in this biome. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| top_material | *not set* | String | Controls the block type used for the surface of this biome. | 
| top_material (Top Material) | *not set* | [Top Material (Top Material)](#top-material-top-material) item |  | 
| type | minecraft:mesa | [Type](#type-choices) choices | Controls the type of surface builder to use. | 

### Clay Material (Clay Material)

#### Clay Material Properties

**JSON path:** `clay_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

### Foundation Material (Foundation Material)

#### Foundation Material Properties

**JSON path:** `foundation_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

### Hard Clay Material (Hard Clay Material)

Same structure as [Clay Material (Clay Material)](#clay-material-clay-material).


### Mid Material (Mid Material)

Same structure as [Foundation Material (Foundation Material)](#foundation-material-foundation-material).


### Sea Floor Material (Sea Floor Material)

Same structure as [Foundation Material (Foundation Material)](#foundation-material-foundation-material).


### Sea Material (Sea Material)

Same structure as [Foundation Material (Foundation Material)](#foundation-material-foundation-material).


### Top Material (Top Material)

Same structure as [Foundation Material (Foundation Material)](#foundation-material-foundation-material).


### Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| minecraft:capped | Minecraft:capped | |
| minecraft:frozen_ocean | Minecraft:frozen ocean | |
| minecraft:mesa | Minecraft:mesa | |
| minecraft:noise_gradient | Minecraft:noise gradient | |
| minecraft:overworld | Minecraft:overworld | |
| minecraft:swamp | Minecraft:swamp | |
| minecraft:the_end | Minecraft:the end | |