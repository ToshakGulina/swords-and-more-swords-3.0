---
author: mammerla
ms.author: mikeam
title: "Biome Documentation - minecraft:creature_spawn_probability"
description: "Describes the minecraft:creature_spawn_probability biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Biome Documentation - minecraft:creature_spawn_probability

Probability that creatures will spawn within the biome when a chunk is generated.


## Biome Creature Spawn Probability Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| probability | *not set* | Decimal number | Probability between [0.0, 0.75] of creatures spawning within the biome on chunk generation. Value must be <= 0.75. | 