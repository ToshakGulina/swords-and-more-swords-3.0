---
author: mammerla
ms.author: mikeam
title: "Biome Documentation - minecraft:biome_definition"
description: "Describes the minecraft:biome_definition biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Biome Documentation - minecraft:biome_definition

Contains a description and components to define a Biome.


## Biome Definition Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| components | *not set* | [Components](#biome-components) item | Components for this Biome. | 
| description | *not set* | [Description](#biome-description) item | Non-component settings, including the Biome name. | 

### Biome Components
Any components that this Biome uses.


#### Biome Components Properties

**JSON path:** `components`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| minecraft:climate | *not set* | [Climate](#biome-climate) item | Describes temperature, humidity, precipitation, and similar. Biomes without this component will have default values. | 
| minecraft:creature_spawn_probability | *not set* | [Creature Spawn Probability](#biome-creature-spawn-probability) item | Probability that creatures will spawn within the biome when a chunk is generated. | 
| minecraft:humidity | *not set* | [Humidity](#biome-humidity) item | Forces a biome to ether always be humid or never humid. Humidity effects the spread chance, and spread rate of fire in the biome | 
| minecraft:map_tints | *not set* | [Map Tints](#biome-map-tints) item | Sets the color grass and foliage will be tinted by in this biome on the map. | 
| minecraft:mountain_parameters | *not set* | [Mountain Parameters](#biome-mountain-parameters) item | Noise parameters used to drive mountain terrain generation in Overworld. | 
| minecraft:multinoise_generation_rules | *not set* | [Multinoise Generation Rules](#biome-multinoise-generation-rules) item | Controls how this biome is instantiated (and then potentially modified) during world generation of the nether. | 
| minecraft:overworld_generation_rules | *not set* | [Overworld Generation Rules](#biome-overworld-generation-rules) item | Controls how this biome is instantiated (and then potentially modified) during world generation of the overworld. | 
| minecraft:overworld_height | *not set* | [Overworld Height](#biome-overworld-height) item | Noise parameters used to drive terrain height in the Overworld. | 
| minecraft:partially_frozen | *not set* | Object | Component will impact the temperature in a frozen biome, causing some areas to not be frozen. Ex: patchy ice, patchy snow | 
| minecraft:replace_biomes | *not set* | [Replace Biomes](#biome-replace-biomes) item | Replaces a specified portion of one or more Minecraft biomes. | 
| minecraft:subsurface_builder | *not set* | [Subsurface Builder](#subsurface-builder) item | Sub Surface Builders allow specifying a `minecraft:surface_builder` to be applied to biomes located underneath regular terrain surface. | 
| minecraft:surface_builder | *not set* | [Surface Builder](#biome-surface-builder) item | Controls materials used for terrain generation. | 
| minecraft:surface_material_adjustments | *not set* | [Surface Material Adjustments](#biome-surface-material-adjustments) item | Specify fine-detail changes to blocks used in terrain generation (based on a noise function). | 
| minecraft:tags | *not set* | [Tags](#biome-tags) item | Attach arbitrary string tags to this biome. | 
| minecraft:village_type | *not set* | [Village Type](#biome-village-type) item | Determines the type of village for the Biome | 

#### minecraft:subsurface_builder

Sub Surface Builders allow specifying a `minecraft:surface_builder` to be applied to biomes located underneath regular terrain surface. Note, however, that pre-existing surface builder types' processing have not been updated to accommodate the ability to specify them for sub-terrain height ranges, which may lead to unexpected results when using them.

#### minecraft:tags

Attach arbitrary string tags to this biome. Most biome tags are referenced by JSON settings, but some meanings of tags are directly implemented in the game's code. These tags are listed here:

- **birch**: Biome uses wildflowers (mutually exclusive with other flower biome tags). Does nothing if biome is tagged "hills".
- **cold**: Villagers will be dressed for snowy weather.
- **deep**: Pre-Caves and Cliffs, prevents an ocean from having islands or connected rivers and makes the biome less likely to have hills.
- **desert**: Allows partially-buried ruined portals to be placed in the biome. Sand blocks will play ambient sounds when the player is nearby.
- **extreme_hills**: Ruined portals can be placed higher than normal. Biomes tagged "forest" or "forest_generation" will use normal Overworld flowers instead of forest flowers.
- **flower_forest**: Biome uses forest flowers (mutually exclusive with other flower biome tags).
- **forest**: Biome uses forest flowers (mutually exclusive with other flower biome tags). Does nothing if biome is tagged tagged "taiga" or "extreme_hills".
- **forest_generation**: Equivalent to "forest".
- **frozen**: Villagers will be dressed for snowy weather. Prevents the biome from containing lava springs if it is also tagged "ocean".
- **ice**: Around ruined portals, lava is always replaced by Netherrack and Netherrack cannot be replaced by magma.
- **ice_plains**: Prevents the biome from containing lava springs if it is also tagged "mutated".
- **jungle**: Ruined portals will be very mossy.
- **hills**: Biomes tagged "meadow" or "birch" will use normal Overworld flowers instead of wildflowers.
- **meadow**: Biome uses wildflowers (mutually exclusive with other flower biome tags). Does nothing if biome is tagged "hills".
- **mesa**: Sand blocks will play ambient sounds when the player is nearby.
- **mountain**: Ruined portals can be placed higher than normal.
- **mutated**: Pre-Caves and Cliffs, prevents switching to the specified "mutate_transformation" as the biome is already considered mutated. Prevents the biome from containing lava springs if it is also tagged "ice_plains".
- **no_legacy_worldgen**: Prevents biome from using legacy world generation behavior unless the biome is being placed in the Overworld.
- **ocean**: Prevents the biome from containing lava springs if it is also tagged "frozen". Allows ruined portals to be found underwater. Pre-Caves and Cliffs, determines if shorelines and rivers should be placed at the edges of the biome and identifies the biome as a shallow ocean for placing islands, unless the "deep" tag is present.
- **pale_garden**: Biome uses closed-eye blossoms (mutually exclusive with other flower biome tags).
- **plains**: Biome uses plains flowers (mutually exclusive with other flower biome tags).
- **rare**: Pre-Caves and Cliffs, this tag flags the biome as a special biome. Oceans cannot be special.
- **swamp**: Allows ruined portals to be found underwater. Biome uses swamp flowers (mutually exclusive with other flower biome tags).
- **taiga**: Biomes tagged "forest" or "forest_generation" will use normal Overworld flowers instead of forest flowers.


#### Biome Climate
Describes temperature, humidity, precipitation, and similar climate properties for a biome. Biomes without this component will use default values. Temperature affects visual effects like snow/ice placement, sponge drying, and sky color. Downfall controls precipitation frequency and intensity.


##### Biome Climate Properties

**JSON path:** `components > minecraft:climate`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| downfall | *not set* | Decimal number | Amount that precipitation affects colors and block changes. Setting to 0 will stop rain from falling in the biome. | 
| snow_accumulation | *not set* | Array of numbers | Minimum and maximum snow level, each multiple of 0.125 is another snow layer Value must have at least 2 items. Value must have at most 2 items. | 
| temperature | *not set* | Decimal number | Temperature affects a variety of visual and behavioral things, including snow and ice placement, sponge drying, and sky color | 

#### Biome Creature Spawn Probability
Probability that creatures will spawn within the biome when a chunk is generated.


##### Biome Creature Spawn Probability Properties

**JSON path:** `components > minecraft:creature_spawn_probability`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| probability | *not set* | Decimal number | Probability between [0.0, 0.75] of creatures spawning within the biome on chunk generation. Value must be <= 0.75. | 

#### Biome Humidity
Forces a biome to ether always be humid or never humid. Humidity effects the spread chance, and spread rate of fire in the biome.


##### Biome Humidity Properties

**JSON path:** `components > minecraft:humidity`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| is_humid | *not set* | Boolean true/false |  | 

#### Biome Map Tints
Sets the color grass and foliage will be tinted by in this biome on the map.


##### Biome Map Tints Properties

**JSON path:** `components > minecraft:map_tints`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| foliage | *not set* | String | Sets the color foliage will be tinted by in this biome on the map. | 
| foliage (as Array of numbers) | *not set* | Array of numbers |  | 
| grass | *not set* | Object | Controls whether the grass will use a custom tint color or a noise based tint color. | 

#### Biome Mountain Parameters
Noise parameters used to drive mountain terrain generation in Overworld.


##### Biome Mountain Parameters Properties

**JSON path:** `components > minecraft:mountain_parameters`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| east_slopes | *not set* | Boolean true/false | Enable for east-facing slopes | 
| material | *not set* | Object | Block type use as steep material | 
| north_slopes | *not set* | Boolean true/false | Enable for north-facing slopes | 
| south_slopes | *not set* | Boolean true/false | Enable for south-facing slopes | 
| steep_material_adjustment | *not set* | [Steep Material Adjustment](#steep-material-adjustment) item | Defines surface material for steep slopes | 
| top_slide | *not set* | [Top Slide](#top-slide) item | Controls the density tapering that happens at the top of the world to prevent terrain from reaching too high | 
| west_slopes | *not set* | Boolean true/false | Enable for west-facing slopes | 

##### Steep Material Adjustment
Defines surface material for steep slopes.


###### Mountain Parameters - Steep Material Adjustment Settings Properties

**JSON path:** `components > minecraft:mountain_parameters > steep_material_adjustment`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| east_slopes | *not set* | Boolean true/false | Enable for east-facing slopes | 
| material | *not set* | String | Block type use as steep material | 
| material (Material) | *not set* | [Material (Material)](#material-material) item |  | 
| north_slopes | *not set* | Boolean true/false | Enable for north-facing slopes | 
| south_slopes | *not set* | Boolean true/false | Enable for south-facing slopes | 
| west_slopes | *not set* | Boolean true/false | Enable for west-facing slopes | 

###### Material (Material)

###### Material Properties

**JSON path:** `components > minecraft:mountain_parameters > steep_material_adjustment > material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

##### Top Slide
Controls the density tapering that happens at the top of the world to prevent terrain from reaching too high.


###### Mountain Parameters - Top Slide Settings Properties

**JSON path:** `components > minecraft:mountain_parameters > top_slide`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| enabled | *not set* | Boolean true/false | If false, top slide will be disabled. If true, other parameters will be taken into account. | 

#### Biome Multinoise Generation Rules
Controls how this biome is instantiated (and then potentially modified) during world generation of the nether.

> [!Note]
> This is a pre-Caves and Cliffs component and is unused for custom biomes.


##### Biome Multinoise Generation Rules Properties

**JSON path:** `components > minecraft:multinoise_generation_rules`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| target_altitude | *not set* | Decimal number | Altitude with which this biome should be generated, relative to other biomes. | 
| target_humidity | *not set* | Decimal number | Humidity with which this biome should be generated, relative to other biomes. | 
| target_temperature | *not set* | Decimal number | Temperature with which this biome should be generated, relative to other biomes. | 
| target_weirdness | *not set* | Decimal number | Weirdness with which this biome should be generated, relative to other biomes. | 
| weight | *not set* | Decimal number | Weight with which this biome should be generated, relative to other biomes. | 

#### Biome Overworld Generation Rules
Controls how this biome is instantiated (and then potentially modified) during world generation of the overworld.

> [!Note]
> This is a pre-Caves and Cliffs component and is unused for custom biomes.


##### Biome Overworld Generation Rules Properties

**JSON path:** `components > minecraft:overworld_generation_rules`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| generate_for_climates | *not set* | String | Controls the world generation climate categories that this biome can spawn for. | 
| hills_transformation | *not set* | Array of strings | An array of any size containing arrays of exactly two elements. | 
| hills_transformation (as String) | *not set* | String |  | 
| mutate_transformation | *not set* | Array of strings | What biome to switch to when converting to a mutated biome | 
| mutate_transformation (as String) | *not set* | String |  | 
| river_transformation | *not set* | Array of strings | What biome to switch to when converting to a river biome (if not the Vanilla 'river' biome) | 
| river_transformation (as String) | *not set* | String |  | 
| shore_transformation | *not set* | Array of strings | What biome to switch to when adjacent to an ocean biome | 
| shore_transformation (as String) | *not set* | String |  | 

##### generate_for_climates

Controls the world generation climate categories that this biome can spawn for. Each entry is an array of [climate_name, weight] where climate_name is 'medium', 'warm', 'lukewarm', 'cold', or 'frozen'.

##### hills_transformation

An array of any size containing arrays of exactly two elements. For each contained array, the first element is a climate category string ('medium', 'warm', 'lukewarm', 'cold', or 'frozen'). The second element is a positive integer for how much that entry is weighted relative to other entries.


#### Biome Overworld Height
Noise parameters used to drive terrain height in the Overworld.

> [!Note]
> This is a pre-Caves and Cliffs component. It does not change overworld height, and currently only affects map item rendering.


##### Biome Overworld Height Properties

**JSON path:** `components > minecraft:overworld_height`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| noise_params | *not set* | Array of numbers | First value is depth - more negative means deeper underwater, while more positive means higher. | 
| noise_type | *not set* | [Noise Type](#noise-type-choices) choices | Specifies a preset based on a built-in setting rather than manually using noise_params | 

##### noise_params

First value is depth - more negative means deeper underwater, while more positive means higher. Second value is scale, which affects how much noise changes as it moves from the surface. Value must have at least 2 items. Value must have at most 2 items.


### Noise Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| beach | Beach | |
| deep_ocean | Deep ocean | |
| default | Default | |
| default_mutated | Default mutated | |
| extreme | Extreme | |
| highlands | Highlands | |
| less_extreme | Less extreme | |
| lowlands | Lowlands | |
| mountains | Mountains | |
| mushroom | Mushroom | |
| ocean | Ocean | |
| river | River | |
| stone_beach | Stone beach | |
| swamp | Swamp | |
| taiga | Taiga | |

#### Biome Replace Biomes
Replaces a specified portion of one or more Minecraft biomes.


##### Biome Replace Biomes Properties

**JSON path:** `components > minecraft:replace_biomes`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| replacements | *not set* | Array of [Replacements](#biome-replacement) items | List of biome replacement configurations. | 

##### replacements

List of biome replacement configurations. Retroactively adding a new replacement to the front of this list will cause the world generation to change. Please add any new replacements to the end of the list.  Check that there is at least one value in the array, that there are no duplicates, and that the dimension is either minecraft:overworld or minecraft:nether.


##### Biome Replacement
Represents the replacement information used to determine the placement of the overriding biome.

> [!Note]
> Custom partial biome replacement is available without experimental toggle in 1.21.110.

> [!Note]
> This item requires a format version of at least 1.21.110.


###### Biome Replacement Properties

**JSON path:** `components > minecraft:replace_biomes > replacements`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| amount | *not set* | Decimal number | Noise value used to determine whether or not the replacement is attempted, similar to a percentage. Must be in the range (0.0, 1.0]. Value must be <= 1. Value must be > 0. | 
| dimension | *not set* | String | Dimension in which this replacement can happen. Can be either 'minecraft:overworld' or 'minecraft:nether'. | 
| noise_frequency_scale | *not set* | Decimal number | Scaling value used to alter the frequency of replacement attempts. | 
| targets | *not set* | Array of strings | Biomes that are going to be replaced by the overriding biome. Target biomes must not contain namespaces. Value must have at least 1 items. | 

###### noise_frequency_scale

Scaling value used to alter the frequency of replacement attempts. A lower frequency will mean a bigger contiguous biome area that occurs less often. A higher frequency will mean smaller contiguous biome areas that occur more often. Must be in the range (0.0, 100.0]. Value must be <= 100. Value must be > 0.


#### Subsurface Builder
Sub Surface Builders allow specifying a `minecraft:surface_builder` to be applied to biomes located underneath regular terrain surface. Note, however, that pre-existing surface builder types' processing have not been updated to accommodate the ability to specify them for sub-terrain height ranges, which may lead to unexpected results when using them.

> [!Note]
> This item requires a format version of at least 1.26.30.


##### Subsurface Builder Properties

**JSON path:** `components > minecraft:subsurface_builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| builder | *not set* | Object | Controls block types and strategy used for terrain generation. | 

#### Biome Surface Builder
Controls materials used for terrain generation.

> [!Note]
> This item requires a format version of at least 1.26.30.


##### Biome Surface Builder Properties

**JSON path:** `components > minecraft:surface_builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| builder (Biome Overworld) | *not set* | [Builder](#biome-overworld) item | Controls block types and strategy used for terrain generation. | 
| builder (Alternate 1) | *not set* | [Builder](#biome-frozen-ocean) item |  | 
| builder (Alternate 2) | *not set* | [Builder](#biome-mesa) item |  | 
| builder (Alternate 3) | *not set* | [Builder](#biome-swamp) item |  | 
| builder (Alternate 4) | *not set* | [Builder](#biome-capped) item |  | 
| builder (Alternate 5) | *not set* | [Builder](#biome-the-end) item |  | 

##### Biome Overworld
Controls the blocks used for the default Minecraft Overworld terrain generation.


###### Biome Overworld Properties

**JSON path:** `components > minecraft:surface_builder > builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| foundation_material | *not set* | String | Controls the block type used deep underground in this biome. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| mid_material | *not set* | String | Controls the block type used in a layer below the surface of this biome. | 
| mid_material (Mid Material) | *not set* | [Mid Material (Mid Material)](#mid-material-mid-material) item |  | 
| sea_floor_depth | *not set* | Integer number | Controls how deep below the world water level the floor should occur. Value must be <= 127. | 
| sea_floor_material | *not set* | String | Controls the block type used as a floor for bodies of water in this biome. | 
| sea_floor_material (Sea Floor Material) | *not set* | [Sea Floor Material (Sea Floor Material)](#sea-floor-material-sea-floor-material) item |  | 
| sea_material | *not set* | String | Controls the block type used for the bodies of water in this biome. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| top_material | *not set* | String | Controls the block type used for the surface of this biome. | 
| top_material (Top Material) | *not set* | [Top Material (Top Material)](#top-material-top-material) item |  | 
| type | minecraft:overworld | [Type](#type-choices) choices | Controls the type of surface builder to use. | 

###### Foundation Material (Foundation Material)

###### Foundation Material Properties

**JSON path:** `components > minecraft:surface_builder > builder > foundation_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

###### Mid Material (Mid Material)

###### Mid Material Properties

**JSON path:** `components > minecraft:surface_builder > builder > mid_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

###### Sea Floor Material (Sea Floor Material)

Same structure as [Mid Material (Mid Material)](#mid-material-mid-material).


###### Sea Material (Sea Material)

Same structure as [Mid Material (Mid Material)](#mid-material-mid-material).


###### Top Material (Top Material)

Same structure as [Mid Material (Mid Material)](#mid-material-mid-material).


### Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| minecraft:capped | Minecraft:capped | |
| minecraft:frozen_ocean | Minecraft:frozen ocean | |
| minecraft:mesa | Minecraft:mesa | |
| minecraft:noise_gradient | Minecraft:noise gradient | |
| minecraft:overworld | Minecraft:overworld | |
| minecraft:swamp | Minecraft:swamp | |
| minecraft:the_end | Minecraft:the end | |

##### Biome Frozen Ocean
Similar to overworld_surface. Adds icebergs.


###### Biome Frozen Ocean Properties

**JSON path:** `components > minecraft:surface_builder > builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| foundation_material | *not set* | String | Controls the block type used deep underground in this biome. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| mid_material | *not set* | String | Controls the block type used in a layer below the surface of this biome. | 
| mid_material (Mid Material) | *not set* | [Mid Material (Mid Material)](#mid-material-mid-material) item |  | 
| sea_floor_depth | *not set* | Integer number | Controls how deep below the world water level the floor should occur. Value must be <= 127. | 
| sea_floor_material | *not set* | String | Controls the block type used as a floor for bodies of water in this biome. | 
| sea_floor_material (Sea Floor Material) | *not set* | [Sea Floor Material (Sea Floor Material)](#sea-floor-material-sea-floor-material) item |  | 
| sea_material | *not set* | String | Controls the block type used for the bodies of water in this biome. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| top_material | *not set* | String | Controls the block type used for the surface of this biome. | 
| top_material (Top Material) | *not set* | [Top Material (Top Material)](#top-material-top-material) item |  | 
| type | minecraft:frozen_ocean | [Type](#type-choices) choices | Controls the type of surface builder to use. | 

##### Biome Mesa
Similar to overworld_surface. Adds colored strata and optional pillars.


###### Biome Mesa Properties

**JSON path:** `components > minecraft:surface_builder > builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| bryce_pillars | *not set* | Boolean true/false | Whether the mesa generates with pillars | 
| clay_material | *not set* | String | Base clay block to use | 
| clay_material (Clay Material) | *not set* | [Clay Material (Clay Material)](#clay-material-clay-material) item |  | 
| foundation_material | *not set* | String | Controls the block type used deep underground in this biome. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| hard_clay_material | *not set* | String | Hardened clay block to use | 
| hard_clay_material (Hard Clay Material) | *not set* | [Hard Clay Material (Hard Clay Material)](#hard-clay-material-hard-clay-material) item |  | 
| has_forest | *not set* | Boolean true/false | Places coarse dirt and grass at high altitudes | 
| mid_material | *not set* | String | Controls the block type used in a layer below the surface of this biome. | 
| mid_material (Mid Material) | *not set* | [Mid Material (Mid Material)](#mid-material-mid-material) item |  | 
| sea_floor_depth | *not set* | Integer number | Controls how deep below the world water level the floor should occur. Value must be <= 127. | 
| sea_floor_material | *not set* | String | Controls the block type used as a floor for bodies of water in this biome. | 
| sea_floor_material (Sea Floor Material) | *not set* | [Sea Floor Material (Sea Floor Material)](#sea-floor-material-sea-floor-material) item |  | 
| sea_material | *not set* | String | Controls the block type used for the bodies of water in this biome. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| top_material | *not set* | String | Controls the block type used for the surface of this biome. | 
| top_material (Top Material) | *not set* | [Top Material (Top Material)](#top-material-top-material) item |  | 
| type | minecraft:mesa | [Type](#type-choices) choices | Controls the type of surface builder to use. | 

###### Clay Material (Clay Material)

###### Clay Material Properties

**JSON path:** `components > minecraft:surface_builder > builder > clay_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

###### Hard Clay Material (Hard Clay Material)

###### Hard Clay Material Properties

**JSON path:** `components > minecraft:surface_builder > builder > hard_clay_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

##### Biome Swamp
Used to add decoration to the surface of swamp biomes such as water lilies.


###### Biome Swamp Properties

**JSON path:** `components > minecraft:surface_builder > builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| foundation_material | *not set* | String | Controls the block type used deep underground in this biome. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| max_puddle_depth_below_sea_level | *not set* | Integer number | Controls the depth at which surface level blocks can be replaced with water for puddles. | 
| mid_material | *not set* | String | Controls the block type used in a layer below the surface of this biome. | 
| mid_material (Mid Material) | *not set* | [Mid Material (Mid Material)](#mid-material-mid-material) item |  | 
| sea_floor_depth | *not set* | Integer number | Controls how deep below the world water level the floor should occur. Value must be <= 127. | 
| sea_floor_material | *not set* | String | Controls the block type used as a floor for bodies of water in this biome. | 
| sea_floor_material (Sea Floor Material) | *not set* | [Sea Floor Material (Sea Floor Material)](#sea-floor-material-sea-floor-material) item |  | 
| sea_material | *not set* | String | Controls the block type used for the bodies of water in this biome. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| top_material | *not set* | String | Controls the block type used for the surface of this biome. | 
| top_material (Top Material) | *not set* | [Top Material (Top Material)](#top-material-top-material) item |  | 
| type | minecraft:swamp | [Type](#type-choices) choices | Controls the type of surface builder to use. | 

###### max_puddle_depth_below_sea_level

Controls the depth at which surface level blocks can be replaced with water for puddles. The number represents the number of blocks (0, 127) below sea level that we will go down to look for a surface block. Value must be <= 127.


##### Biome Capped
Generates surface on blocks with non-solid blocks above or below.


###### Biome Capped Properties

**JSON path:** `components > minecraft:surface_builder > builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| beach_material | *not set* | String | Material used to decorate surface near sea level. | 
| beach_material (Beach Material) | *not set* | [Beach Material (Beach Material)](#beach-material-beach-material) item |  | 
| ceiling_materials | *not set* | String | Materials used for the surface ceiling. Value must have at least 1 items. | 
| ceiling_materials (Ceiling Materials) | *not set* | [Ceiling Materials (Ceiling Materials)](#ceiling-materials-ceiling-materials) item |  | 
| floor_materials | *not set* | String | Materials used for the surface floor. Value must have at least 1 items. | 
| floor_materials (Floor Materials) | *not set* | [Floor Materials (Floor Materials)](#floor-materials-floor-materials) item |  | 
| foundation_material | *not set* | String | Material used to replace solid blocks that are not surface blocks. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| sea_material | *not set* | String | Material used to replace air blocks below sea level. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| type | minecraft:capped | [Type](#type-choices) choices | Controls the type of surface builder to use | 

###### Beach Material (Beach Material)

###### Beach Material Properties

**JSON path:** `components > minecraft:surface_builder > builder > beach_material`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

###### Ceiling Materials (Ceiling Materials)

###### Ceiling Materials Properties

**JSON path:** `components > minecraft:surface_builder > builder > ceiling_materials`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| name | *not set* | Object | Name of the block | 
| states | {} | Keyed set of numbers | Contains members named after each state, with boolean, integer, or string values. | 
| states (as Keyed collection of boolean values) | *not set* | Keyed collection of boolean values |  | 
| states (as Keyed set of strings) | *not set* | Keyed set of strings |  | 

###### Floor Materials (Floor Materials)

Same structure as [Ceiling Materials (Ceiling Materials)](#ceiling-materials-ceiling-materials).


##### Biome The End
Marks a biome as using End dimension terrain generation. Biomes with this component will use the characteristic End terrain style with end stone and void generation.


###### Biome The End Properties

**JSON path:** `components > minecraft:surface_builder > builder`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| type | minecraft:the_end | [Type](#type-choices) choices | Use default Minecraft End terrain generation. | 

#### Biome Surface Material Adjustments
Specify fine-detail changes to blocks used in terrain generation (based on a noise function).


##### Biome Surface Material Adjustments Properties

**JSON path:** `components > minecraft:surface_material_adjustments`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| adjustments | *not set* | Array of [Adjustments](#adjustments) items | All adjustments that match the column's noise values will be applied in the order listed. | 

##### Adjustments
An adjustment to generated terrain, replacing blocks based on the specified settings.


###### Surface Material Adjustments - Surface Adjustment Settings Properties

**JSON path:** `components > minecraft:surface_material_adjustments > adjustments`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| height_range | *not set* | Decimal number | Defines a range of noise values [min, max] for which this adjustment should be applied. Value must have at least 2 items. Value must have at most 2 items. | 
| height_range (as Boolean true/false) | *not set* | Boolean true/false |  | 
| height_range (as String) | *not set* | String |  | 
| materials | *not set* | [Materials](#materials) item | The specific blocks used for this surface adjustment | 
| noise_frequency_scale | *not set* | Decimal number | The scale to multiply by the position when accessing the noise value for the material adjustments. | 
| noise_range | *not set* | Array of numbers | Defines a range of noise values [min, max] for which this adjustment should be applied. Value must have at least 2 items. Value must have at most 2 items. | 

###### Materials
The specific blocks used for this surface adjustment.


###### Surface Material Adjustments - Surface Adjustment Materials Settings Properties

**JSON path:** `components > minecraft:surface_material_adjustments > adjustments > materials`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| foundation_material | *not set* | String | Controls the block type used deep underground in this biome when this adjustment is active. | 
| foundation_material (Foundation Material) | *not set* | [Foundation Material (Foundation Material)](#foundation-material-foundation-material) item |  | 
| mid_material | *not set* | String | Controls the block type used in a layer below the surface of this biome when this adjustment is active. | 
| mid_material (Mid Material) | *not set* | [Mid Material (Mid Material)](#mid-material-mid-material) item |  | 
| sea_floor_material | *not set* | String | Controls the block type used as a floor for bodies of water in this biome when this adjustment is active. | 
| sea_floor_material (Sea Floor Material) | *not set* | [Sea Floor Material (Sea Floor Material)](#sea-floor-material-sea-floor-material) item |  | 
| sea_material | *not set* | String | Controls the block type used in the bodies of water in this biome when this adjustment is active. | 
| sea_material (Sea Material) | *not set* | [Sea Material (Sea Material)](#sea-material-sea-material) item |  | 
| top_material | *not set* | String | Controls the block type used for the surface of this biome when this adjustment is active. | 
| top_material (Top Material) | *not set* | [Top Material (Top Material)](#top-material-top-material) item |  | 

#### Biome Tags
Attach arbitrary string tags to this biome.
Most biome tags are referenced by JSON settings, but some meanings of tags are directly implemented in the game's code. These tags are listed here:
birch: Biome uses wildflowers (mutually exclusive with other flower biome tags). Does nothing if biome is tagged "hills".
cold: Villagers will be dressed for snowy weather.
deep: Pre-Caves and Cliffs, prevents an ocean from having islands or connected rivers and makes the biome less likely to have hills.
desert: Allows partially-buried ruined portals to be placed in the biome. Sand blocks will play ambient sounds when the player is nearby.
extreme_hills: Ruined portals can be placed higher than normal. Biomes tagged "forest" or "forest_generation" will use normal Overworld flowers instead of forest flowers.
flower_forest: Biome uses forest flowers (mutually exclusive with other flower biome tags).
forest: Biome uses forest flowers (mutually exclusive with other flower biome tags). Does nothing if biome is tagged tagged "taiga" or "extreme_hills".
forest_generation: Equivalent to "forest".
frozen: Villagers will be dressed for snowy weather. Prevents the biome from containing lava springs if it is also tagged "ocean".
ice: Around ruined portals, lava is always replaced by Netherrack and Netherrack cannot be replaced by magma.
ice_plains: Prevents the biome from containing lava springs if it is also tagged "mutated".
jungle: Ruined portals will be very mossy.
hills: Biomes tagged "meadow" or "birch" will use normal Overworld flowers instead of wildflowers.
meadow: Biome uses wildflowers (mutually exclusive with other flower biome tags). Does nothing if biome is tagged "hills".
mesa: Sand blocks will play ambient sounds when the player is nearby.
mountain: Ruined portals can be placed higher than normal.
mutated: Pre-Caves and Cliffs, prevents switching to the specified "mutate_transformation" as the biome is already considered mutated. Prevents the biome from containing lava springs if it is also tagged "ice_plains".
no_legacy_worldgen: Prevents biome from using legacy world generation behavior unless the biome is being placed in the Overworld.
ocean: Prevents the biome from containing lava springs if it is also tagged "frozen". Allows ruined portals to be found underwater. Pre-Caves and Cliffs, determines if shorelines and rivers should be placed at the edges of the biome and identifies the biome as a shallow ocean for placing islands, unless the "deep" tag is present.
pale_garden: Biome uses closed-eye blossoms (mutually exclusive with other flower biome tags).
plains: Biome uses plains flowers (mutually exclusive with other flower biome tags).
rare: Pre-Caves and Cliffs, this tag flags the biome as a special biome. Oceans cannot be special.
swamp: Allows ruined portals to be found underwater. Biome uses swamp flowers (mutually exclusive with other flower biome tags).
taiga: Biomes tagged "forest" or "forest_generation" will use normal Overworld flowers instead of forest flowers.


##### Biome Tags Properties

**JSON path:** `components > minecraft:tags`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| tags | *not set* | Array of strings | Array of string tags used by other systems such as entity spawning | 

#### Biome Village Type
Determines the type of village for the Biome.

> [!Note]
> Biome component added in 1.26.0 that determines the type of village (default, desert, ice, savanna, or taiga) that generates in this biome.

> [!Note]
> This item requires a format version of at least 1.26.0.


##### Biome Village Type Properties

**JSON path:** `components > minecraft:village_type`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| type | *not set* | [Type](#type-choices) choices |  | 

### Type choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| default | Default | |
| desert | Desert | |
| ice | Ice | |
| savanna | Savanna | |
| taiga | Taiga | |

### Biome Description
Contains non-component settings for a Biome.


#### Biome Description Properties

**JSON path:** `description`

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| identifier | *not set* | String | The name of the Biome, used by other features like the '/locate biome' command. | 

#### identifier

The name of the Biome, used by other features like the '/locate biome' command. Identifiers should only be lowercase. Value must match a regular expression pattern of "^[a-z0-9._%+-]+:[a-z0-9._%+-]+$".
