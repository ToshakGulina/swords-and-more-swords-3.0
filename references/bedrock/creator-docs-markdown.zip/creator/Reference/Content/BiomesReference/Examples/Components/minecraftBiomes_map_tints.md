---
author: mammerla
ms.author: mikeam
title: "Biome Documentation - minecraft:map_tints"
description: "Describes the minecraft:map_tints biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Biome Documentation - minecraft:map_tints

Sets the color grass and foliage will be tinted by in this biome on the map.


## Biome Map Tints Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| foliage | *not set* | String | Sets the color foliage will be tinted by in this biome on the map. | 
| foliage (as Array of numbers) | *not set* | Array of numbers |  | 
| grass | *not set* | Object | Controls whether the grass will use a custom tint color or a noise based tint color. | 