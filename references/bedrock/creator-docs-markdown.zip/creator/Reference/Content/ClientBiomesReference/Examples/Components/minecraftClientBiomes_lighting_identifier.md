---
author: mammerla
ms.author: mikeam
title: "Client Biome Documentation - minecraft:lighting_identifier"
description: "Describes the minecraft:lighting_identifier client biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Client Biome Documentation - minecraft:lighting_identifier

Set the identifier used for lighting in Vibrant Visuals mode. Identifiers must resolve to identifiers in valid Lighting JSON schemas under the "lighting" directory. Biomes without this component will have default lighting settings.


## Client Biome Lighting Identifier Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| lighting_identifier | *not set* | String | Identifier of lighting definition to use | 