---
author: mammerla
ms.author: mikeam
title: "Client Biome Documentation - minecraft:client_biome_description"
description: "Describes the minecraft:client_biome_description client biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Client Biome Documentation - minecraft:client_biome_description

Contains non-component settings for a Client Biome.


## Client Biome Description Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| identifier | *not set* | String | The name of the Client Biome, used by other features like the '/locate biome' command. | 

### identifier

The name of the Client Biome, used by other features like the '/locate biome' command. Must match the name of a Biome defined by the game or a behavior pack. Value must match a regular expression pattern of "^[a-z0-9._%+-]+:[a-z0-9._%+-]+$".
