---
author: mammerla
ms.author: mikeam
title: "Client Biome Documentation - minecraft:grass_color_map"
description: "Describes the minecraft:grass_color_map client biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Client Biome Documentation - minecraft:grass_color_map

Object specifying a color map for grass instead of a specific color.


## Client Biome Grass Color Map Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| color_map | *not set* | [Color Map](#color-map-choices) choices | Color map from textures/colormap to determine color of grass. | 

### Color Map choices

|Value       |Title |Description |
|:-----------|:-----|:-----------|
| grass | Grass | |
| swamp_grass | Swamp grass | |