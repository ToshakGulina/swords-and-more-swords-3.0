---
author: mammerla
ms.author: mikeam
title: "Client Biome Documentation - minecraft:ambient_sounds"
description: "Describes the minecraft:ambient_sounds client biome"
ai-usage: ai-assisted
ms.service: minecraft-bedrock-edition
ms.date: 02/11/2025 
---

# Client Biome Documentation - minecraft:ambient_sounds

Sets the ambient sounds for the biome. These sounds must be in the 'individual_named_sounds' in a 'sounds.json' file.

> [!Note]
> This item requires a format version of at least 1.21.50.


## Minecraft Ambient Sounds Properties

|Name       |Default Value |Type |Description |
|:----------|:-------------|:----|:-----------|
| addition |  | String | Named sound that occasionally plays at the listener position | 
| loop |  | String | Named sound that loops while the listener position is inside the biome | 
| mood |  | String | Named sound that rarely plays at a nearby air block position when the light level is low. Biomes without an ambient mood sound will use the 'ambient.cave' sound. | 